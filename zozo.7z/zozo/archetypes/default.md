---
title: {{ replace .File.ContentBaseName "-" " " | title }}
date: {{ .Date }}
draft: false
slug: " "
categories:
  -
tags:
  - 
---

<!--more--> 
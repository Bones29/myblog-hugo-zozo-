---
title: Docker Compose部署Wordpress
date: 2024-06-01T10:56:23+08:00
draft: false
slug: "dockercompose"
categories: 
  - docker
tags: 
  - docker
  - wordpress
---
docker compose部署wordpress与mysql
<!--more-->  
### 学习记录

镜像版本：
mysql：8.0
wordpress：6.5.3
## 配置docker的阿里云yum源
```
curl -o /etc/yum.repos.d/docker-ce.repo  https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```
安装启动docker
```
yum install docker-ce -y
systemctl enable docker --now
```
## 配置阿里云镜像加速
```
tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://q2gr04ke.mirror.aliyuncs.com"]
}
EOF
```
## 编写compose清单文件（数据库密码等信息可自行修改）
```
vi docker-compose.yml 
 
下面的复制进去
services:
  mysql:
    image: mysql:8.0
    restart: always
    environment:
      MYSQL_ROOT_PASSWORD: docker123@com  ##数据库root密码 
      MYSQL_DATABASE: wordpress           ##数据库名称
      MYSQL_USER: docker                  ##创建用户docker设定密码
      MYSQL_PASSWORD: docker@wp           
    networks:
      - blog_net
    volumes:
      - mysql_data:/var/lib/mysql    ##使用mysql_data卷持久化容器的/var/lib/mysql数据目录
  wordpress:
    depends_on:
      - mysql
    image: wordpress:6.5.3
    environment:
      WORDPRESS_DB_HOST: mysql:3306  
      WORDPRESS_DB_NAME: wordpress
      WORDPRESS_DB_USER: docker   
      WORDPRESS_DB_PASSWORD: docker@wp
    ports:
      - 80:80
    networks:
      - blog_net
    volumes:
      - /data/wordpress:/var/www/html   ##wordpress数据存储位置
 
##自定义容器网络名称blog_net、驱动类型为bridge、地址段范围为172.16.0.0/24。
networks:
  blog_net:
    driver: bridge                    
    ipam:
      config:
        - subnet: 172.16.0.0/24
 
##使用volumes创建卷 mysql_data      
volumes:
  mysql_data:
```
## 启动容器 
-d后台运行
```
docker compose up -d
```
docker ps 查看容器运行状态

浏览器输入你的公网ip或者域名測試
## 删除博客及容器镜像
```
##停止容器
docker compose stop
##删除容器
docker rm root-wordpress-1 && docker rm root-mysql-1
```
删除镜像
```
docker rmi wordpress:6.5.3
docker rmi mysql:8.0
```
彻底删除数据
```
##wordpress数据
rm -rf /data/wordpress/*
##mysql
docker volume rm root_mysql_data
```
---
title: "Dockerfile构建镜像"
date: 2024-05-23 22:41:38
hidden: false
comments: true
draft: false
slug: "dockerfile"
categories:
   - docker
tags: 
  - dockerfile
---
## 学习记录
## Dockerfile基本语法

FROM 指定基础镜像

RUN 执行命令

ADD和COPY都是用来将宿主机的文件复制到镜像里，COPY 只支持复制文件，而ADD支持压缩文件自动解压

WORKDIR 设置工作目录

ENV 设置环境变量

EXPOSE 声明镜像暴露的端口

CMD 指定容器启动时执行的命令，CMD只能有一条

ENTRYPOINT和CMD类似，可以有多条
## 安装配置docker

### 配置docker的yum源并安装
```bash
curl -o /etc/yum.repos.d/docker-ce.repo  https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
yum install docker-ce -y
```
### 配置阿里云镜像加速
```
tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://q2gr04ke.mirror.aliyuncs.com"]
}

systemctl daemon-reload && systemctl restart docker
EOF
```
### 更改docker存储目录
把这一行加进去 "data-root": "/data/docker"
```
vi /etc/docker/daemon.json
{
  "registry-mirrors": ["https://q2gr04ke.mirror.aliyuncs.com"],
  "data-root": "/data/docker"
}
```
## 编写dockerfile
```
cat Dockerfile

FROM rockylinux:9.3
WORKDIR /root/wp
#nginx
COPY ./nginx.repo /etc/yum.repos.d/
RUN yum install -y epel-release nginx 
RUN rm -rf /etc/nginx/conf.d/*
COPY ./cll.conf /etc/nginx/conf.d/
#php
RUN mkdir -p /run/php-fpm && chown -R nginx.nginx /run/php-fpm && chmod -R 755 /run/php-fpm
RUN yum install -y php php-fpm php-cli \
php-common php-devel php-embedded php-gd php-mcrypt php-bcmath php-mbstring php-pdo php-xml \
php-mysqlnd php-opcache php-pecl-zip php-pecl-redis php-pecl-mongodb
RUN sed -i '/^user/c user = nginx' /etc/php-fpm.d/www.conf && sed -i '/^group/c group = nginx' /etc/php-fpm.d/www.conf && sed -i  '/^listen =/c listen = 127.0.0.1:9000' /etc/php-fpm.d/www.conf
#wordpress
RUN mkdir /data
ADD wordpress-6.5.3-zh_CN.tar.gz /usr/share/nginx
RUN chown -R nginx.nginx /usr/share/nginx/wordpress
ENV DBPASS=123456
EXPOSE 80 3306 443
#脚本
COPY start.sh /usr/local/bin/
RUN chmod +x /usr/local/bin/start.sh
ENTRYPOINT ["start.sh"]
```
## 准备nginx配置文件与启动脚本
```
tee cll.conf <<-'EOF'
server {
	listen 80;
	server_name 域名或ip地址;
	root /usr/share/nginx/wordpress;
        #配置客户端请求体最大值
        client_max_body_size 20M;
        #配置请求体缓存区大小
        client_body_buffer_size 20M;         

	location / {
		index index.php index.html;
        }
	location ~ \.php$ {
		fastcgi_pass 127.0.0.1:9000;
		fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
		include fastcgi_params;
	}
}
EOF
```
### 脚本
```
cat start.sh 
#!/bin/bash  
set -e  
# 启动 PHP-FPM  
php-fpm &  
# 启动 Nginx  
exec nginx -g "daemon off;"
```
### 目录配置文件如下
  
## 构建wordpress镜像
-t 命名
```
docker build -t wordpress:v1 .
```
## 启动wordpress
### 拉去mysql 8.0镜像并启动
```
 docker pull mysql:8.0
 docker run -itd  -e MYSQL_ROOT_PASSWORD=123456 -e MYSQL_DATABASE=wordpress --name mysql mysql:latest
```
### 启动wordpress
link 容器互联
```
docker run -itd --link mysql -p 80:80 --name web wordpress:v1 /bin/bash
```
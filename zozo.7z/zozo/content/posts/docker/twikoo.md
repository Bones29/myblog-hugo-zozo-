---
title: Docker部署Twikoo
date: 2024-06-04 20:16:42
updated:
slug: "twikoo"
categories: 
  - docker
  - 建站记录
tags:
  - docker
  - twikoo
---
docker compose部署twikoo评论系统并配置https
<!--more-->  
## 安装配置docker
[点我](/posts/docker/dockerfile/)
## 拉取Twikoo镜像
``` bash
docker pull imaegoo/twikoo
```
## 编写yaml文件
### 将宿主机8087端口映射到容器8080
    ports:
      - 8087:8080
### 将容器的/app/data/目录持久化到宿主机当前目录的data下
    volumes:
      - ./data:/app/data
``` bash
tee docker-compose.yml <<-'EOF'
version: '3'
services:
  twikoo:
    image: imaegoo/twikoo
    container_name: twikoo
    restart: unless-stopped
    ports:
      - 8087:8080
    environment:
      TWIKOO_THROTTLE: 1000
    volumes:
      - ./data:/app/data
EOF
```
## 启动twikoo容器
-d 后台运行
``` bash
docker compose up -d
```
docker ps 查看容器状态
## 放行ecs防火墙的8087端口
## 为twikoo配置https
### 申请一个子域名并准备对应的ssl证书
### 配置nginx代理
```
cat kshar.cn.conf
server {
     listen 80;
     listen 443 ssl;
     server_name cmm.clls.online;
     #强制SSL
     if ($server_port !~ 443){
        rewrite ^(/.*)$ https://$host$1 permanent;
     }
     ssl_session_cache shared:SSL:1m;
     ssl_session_timeout 5m;	 
     ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
     ssl_protocols TLSv1.2 TLSv1.3;
     ssl_prefer_server_ciphers on;
     ##ssl路径
     ssl_certificate     /cert/twikoo/xxx.pem;
     ssl_certificate_key /cert/twikoo/xxx.key;

    location / {
            proxy_pass  http://localhost+端口;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_set_header REMOTE-HOST $remote_addr;
       }
}
```
## 重启nginx
```
nginx -t
systemctl restart nginx
```
---
title: Certbot申请ssl证书并自动续签
date: 2024-06-26T11:19:12+08:00
draft: false
slug: "certbot"
categories:
  - 博客
tags:
  - ssl
  - certbot
---
Certbot 是一个由 Let's Encrypt 开发的免费开源工具，用于自动化部署和管理 SSL/TLS 证书，并使用crontab自动续期。
<!--more--> 
## 1.安装epel源与certbot
```
yum install epel-release -y
yum -y update && yum -y install certbot
```
## 2.申请证书
停止nginx
```
systemctl stop nginx
certbot certonly --standalone -d 域名 --email 邮箱 --agree-tos --no-eff-email --force-renewal
```
证书存放目录目录为：/etc/letsencrypt/live/
## 3.编写自动续签脚本
内容自行修改
```
cat auto_cert_renewal-1.sh 
# 定义证书存储目录
certs_directory="/etc/letsencrypt/live/"
 
days_before_expiry=5  # 设置在证书到期前几天触发续签
 
# 遍历所有证书文件
for cert_dir in $certs_directory*; do
    # 获取域名
    domain=$(basename "$cert_dir")
 
    # 忽略 README 目录
    if [ "$domain" = "README" ]; then
        continue
    fi
 
    # 输出正在检查的证书信息
    echo "检查证书过期日期： ${domain}"
 
    # 获取fullchain.pem文件路径
    cert_file="${cert_dir}/fullchain.pem"
 
    # 获取证书过期日期
    expiration_date=$(openssl x509 -enddate -noout -in "${cert_file}" | cut -d "=" -f 2-)
 
    # 输出证书过期日期
    echo "过期日期： ${expiration_date}"
 
    # 将日期转换为时间戳
    expiration_timestamp=$(date -d "${expiration_date}" +%s)
    current_timestamp=$(date +%s)
 
    # 计算距离过期还有几天
    days_until_expiry=$(( ($expiration_timestamp - $current_timestamp) / 86400 ))
 
    # 检查是否需要续签（在满足续签条件的情况下）
    if [ $days_until_expiry -le $days_before_expiry ]; then
        echo "证书将在${days_before_expiry}天内过期，正在进行自动续签。"
 
        # 停止 Nginx
        systemctl stop nginx
 
        # 续签证书
        certbot certonly --standalone -d $domain --email 1172338990@qq.com --agree-tos --no-eff-email --force-renewal
 
        # 启动 Nginx
        systemctl start nginx
 
        echo "证书已成功续签。"
    else
        # 若未满足续签条件，则输出证书仍然有效
        echo "证书仍然有效，距离过期还有 ${days_until_expiry} 天。"
    fi
 
    # 输出分隔线
    echo "--------------------------"
done
```
添加执行权限并测试
```
chmod +x auto_cert_renewal-1.sh
 
sh auto_cert_renewal-1.sh 
检查证书过期日期： kshar.cn
过期日期： Sep 23 07:56:22 2024 GMT
证书仍然有效，距离过期还有 89 天。
--------------------------
```
## 4.设置定时任务
```
echo "0 0 * * * cd ~ && ./auto_cert_renewal-1.sh" | crontab -
```